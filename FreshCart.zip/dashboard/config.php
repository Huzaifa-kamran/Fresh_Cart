<?php 
$conn = mysqli_connect("localhost","root","","freshcart");

// if ($conn) {
//     echo "Connection Established";
// }

?>